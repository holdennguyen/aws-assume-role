#!/bin/bash

# AWS Assume Role CLI v1.2.0 - Environment Debug Information
# Enhanced debug script for installation and environment troubleshooting

echo "🔍 AWS Assume Role CLI v1.2.0 - Environment Debug Information"
echo "============================================================="
echo "🔒 Security: AWS SDK v1.x with aws-lc-rs (ring vulnerabilities resolved)"
echo "🧪 Testing: 55 comprehensive tests (23 unit + 14 integration + 18 shell)"
echo ""

echo "📍 System Information:"
echo "  Operating System: $(uname -s 2>/dev/null || echo 'unknown')"
echo "  Architecture: $(uname -m 2>/dev/null || echo 'unknown')"
echo "  Kernel: $(uname -r 2>/dev/null || echo 'unknown')"
echo "  Date: $(date 2>/dev/null || echo 'unknown')"

echo ""
echo "🐚 Shell Information:"
echo "  SHELL: ${SHELL:-'not set'}"
echo "  OSTYPE: ${OSTYPE:-'not set'}"
echo "  BASH_VERSION: ${BASH_VERSION:-'not set'}"
echo "  ZSH_VERSION: ${ZSH_VERSION:-'not set'}"
echo "  FISH_VERSION: ${FISH_VERSION:-'not set'}"

echo ""
echo "🪟 Windows Environment Variables:"
echo "  WINDIR: ${WINDIR:-'not set'}"
echo "  SYSTEMROOT: ${SYSTEMROOT:-'not set'}"
echo "  USERPROFILE: ${USERPROFILE:-'not set'}"
echo "  HOMEDRIVE: ${HOMEDRIVE:-'not set'}"
echo "  HOMEPATH: ${HOMEPATH:-'not set'}"
echo "  WSL_DISTRO_NAME: ${WSL_DISTRO_NAME:-'not set'}"

echo ""
echo "🛠️ Available Commands:"
echo "  winpty: $(command -v winpty 2>/dev/null || echo 'not found')"
echo "  cmd: $(command -v cmd 2>/dev/null || echo 'not found')"
echo "  powershell: $(command -v powershell 2>/dev/null || echo 'not found')"
echo "  pwsh: $(command -v pwsh 2>/dev/null || echo 'not found')"
echo "  fish: $(command -v fish 2>/dev/null || echo 'not found')"
echo "  zsh: $(command -v zsh 2>/dev/null || echo 'not found')"

echo ""
echo "☁️ AWS Environment:"
echo "  aws: $(command -v aws 2>/dev/null || echo 'not found')"
if command -v aws >/dev/null 2>&1; then
    echo "  AWS CLI Version: $(aws --version 2>&1 | head -1 || echo 'unknown')"
fi
echo "  AWS_PROFILE: ${AWS_PROFILE:-'not set'}"
echo "  AWS_REGION: ${AWS_REGION:-'not set'}"
echo "  AWS_DEFAULT_REGION: ${AWS_DEFAULT_REGION:-'not set'}"

echo ""
echo "📁 Current Directory:"
echo "  PWD: $(pwd)"
echo "  Directory contents:"
ls -la

echo ""
echo "🔍 AWS Assume Role Files:"
echo "  aws-assume-role.exe: $([ -f 'aws-assume-role.exe' ] && echo '✅ found' || echo '❌ not found')"
echo "  aws-assume-role-unix: $([ -f 'aws-assume-role-unix' ] && echo '✅ found' || echo '❌ not found')"
echo "  aws-assume-role-macos: $([ -f 'aws-assume-role-macos' ] && echo '✅ found' || echo '❌ not found')"
echo "  INSTALL.sh: $([ -f 'INSTALL.sh' ] && echo '✅ found' || echo '❌ not found')"
echo "  INSTALL.ps1: $([ -f 'INSTALL.ps1' ] && echo '✅ found' || echo '❌ not found')"

echo ""
echo "🐚 Shell Wrapper Scripts:"
echo "  aws-assume-role-bash.sh: $([ -f 'aws-assume-role-bash.sh' ] && echo '✅ found' || echo '❌ not found')"
echo "  aws-assume-role-fish.fish: $([ -f 'aws-assume-role-fish.fish' ] && echo '✅ found' || echo '❌ not found')"
echo "  aws-assume-role-powershell.ps1: $([ -f 'aws-assume-role-powershell.ps1' ] && echo '✅ found' || echo '❌ not found')"
echo "  aws-assume-role-cmd.bat: $([ -f 'aws-assume-role-cmd.bat' ] && echo '✅ found' || echo '❌ not found')"

echo ""
echo "🔖 Version Information:"
# Check binary versions if they exist
for binary in aws-assume-role.exe aws-assume-role-unix aws-assume-role-macos; do
    if [[ -f "$binary" ]]; then
        echo "  $binary version: $(./"$binary" --version 2>/dev/null || echo 'unable to determine')"
    fi
done

echo ""
echo "🧪 OS Detection Test:"
# Replicate the detection logic from INSTALL.sh
OS="unknown"
if [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macos"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="linux"
elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "win32" ]]; then
    OS="gitbash"
elif [[ "$OSTYPE" == *"msys"* ]] || [[ "$OSTYPE" == *"mingw"* ]] || [[ "$OSTYPE" == *"cygwin"* ]]; then
    OS="gitbash"
elif command -v winpty >/dev/null 2>&1 || [[ -n "$WINDIR" ]] || [[ -n "$SYSTEMROOT" ]]; then
    echo "  Windows environment detected via fallback method"
    OS="gitbash"
fi

echo "  Detected OS: $OS"

case $OS in
    "macos")
        EXPECTED_BINARY="aws-assume-role-macos"
        EXPECTED_WRAPPER="aws-assume-role-bash.sh"
        ;;
    "linux")
        EXPECTED_BINARY="aws-assume-role-unix"
        EXPECTED_WRAPPER="aws-assume-role-bash.sh"
        ;;
    "gitbash")
        EXPECTED_BINARY="aws-assume-role.exe"
        EXPECTED_WRAPPER="aws-assume-role-cmd.bat or aws-assume-role-powershell.ps1"
        ;;
    *)
        EXPECTED_BINARY="unknown"
        EXPECTED_WRAPPER="unknown"
        ;;
esac

echo "  Expected binary: $EXPECTED_BINARY"
echo "  Binary exists: $([ -f "$EXPECTED_BINARY" ] && echo '✅ yes' || echo '❌ no')"
echo "  Expected wrapper: $EXPECTED_WRAPPER"

echo ""
echo "🔧 Installation Validation:"
# Check if aws-assume-role is in PATH
if command -v aws-assume-role >/dev/null 2>&1; then
    echo "  ✅ aws-assume-role found in PATH"
    echo "  Installed version: $(aws-assume-role --version 2>/dev/null || echo 'unable to determine')"
    echo "  Location: $(command -v aws-assume-role)"
else
    echo "  ❌ aws-assume-role not found in PATH"
fi

# Check if awsr wrapper is available
if command -v awsr >/dev/null 2>&1; then
    echo "  ✅ awsr wrapper found in PATH"
    echo "  Location: $(command -v awsr)"
else
    echo "  ❌ awsr wrapper not found in PATH"
fi

echo ""
echo "📝 Configuration Check:"
CONFIG_DIR="$HOME/.aws-assume-role"
CONFIG_FILE="$CONFIG_DIR/config.json"
echo "  Config directory: $CONFIG_DIR"
echo "  Config directory exists: $([ -d "$CONFIG_DIR" ] && echo '✅ yes' || echo '❌ no')"
echo "  Config file exists: $([ -f "$CONFIG_FILE" ] && echo '✅ yes' || echo '❌ no')"
if [[ -f "$CONFIG_FILE" ]]; then
    ROLE_COUNT=$(jq -r '.roles | length' "$CONFIG_FILE" 2>/dev/null || echo 'unable to parse')
    echo "  Configured roles: $ROLE_COUNT"
fi

echo ""
echo "🎯 Shell Integration Test:"
# Test shell integration for current shell
case "$SHELL" in
    */bash|*/zsh)
        echo "  Current shell: Bash/Zsh compatible"
        echo "  Recommended wrapper: aws-assume-role-bash.sh"
        echo "  Integration test: source aws-assume-role-bash.sh && awsr --help"
        ;;
    */fish)
        echo "  Current shell: Fish"
        echo "  Recommended wrapper: aws-assume-role-fish.fish"
        echo "  Integration test: source aws-assume-role-fish.fish && awsr --help"
        ;;
    *)
        echo "  Current shell: $(basename "$SHELL" 2>/dev/null || echo 'unknown')"
        echo "  Recommended: Use bash wrapper or direct binary"
        ;;
esac

echo ""
echo "💡 Troubleshooting Recommendations:"
if [[ "$OS" == "unknown" ]]; then
    echo "  ❌ OS detection failed. Try:"
    echo "     1. OSTYPE=msys ./INSTALL.sh (for Git Bash)"
    echo "     2. Use PowerShell: .\INSTALL.ps1"
    echo "     3. Manual installation (see README.md)"
    echo "     4. Check if running in WSL: echo \$WSL_DISTRO_NAME"
elif [[ "$OS" == "gitbash" ]] && [[ ! -f "aws-assume-role.exe" ]]; then
    echo "  ❌ Git Bash detected but aws-assume-role.exe not found"
    echo "     1. Ensure you downloaded the correct release package"
    echo "     2. Extract the full package contents"
    echo "     3. Run this script from the extracted directory"
    echo "     4. Try PowerShell installation: .\INSTALL.ps1"
elif [[ "$OS" == "gitbash" ]] && [[ -f "aws-assume-role.exe" ]]; then
    echo "  ✅ Git Bash detected and aws-assume-role.exe found"
    echo "     The installation should work. If it doesn't:"
    echo "     1. Try running as administrator"
    echo "     2. Use PowerShell instead: .\INSTALL.ps1"
    echo "     3. Check Windows Defender/antivirus settings"
else
    echo "  ✅ Environment looks good for installation"
fi

# Version-specific recommendations
echo ""
echo "  📦 Installation Options (v1.2.0):"
echo "     • Package Managers: brew, apt, dnf, cargo install aws-assume-role"
echo "     • Manual: Extract this package and run INSTALL.sh/INSTALL.ps1"
echo "     • Container: docker pull ghcr.io/holdennguyen/aws-assume-role:v1.2.0"

echo ""
echo "🚀 Next Steps:"
echo "  1. For Unix/Linux/macOS: ./INSTALL.sh"
echo "  2. For Windows PowerShell: .\INSTALL.ps1"
echo "  3. For Git Bash: ./INSTALL.sh or .\INSTALL.ps1"
echo "  4. Verify installation: aws-assume-role --version"
echo "  5. Check prerequisites: aws-assume-role verify"
echo "  6. If issues persist, share this debug output for support"

echo ""
echo "📋 Debug Information Complete!"
echo "   Report issues: https://github.com/holdennguyen/aws-assume-role/issues"
echo "   Documentation: https://github.com/holdennguyen/aws-assume-role#readme" 