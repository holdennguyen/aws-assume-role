#!/bin/bash

# Debug script for AWS Assume Role CLI installation issues
echo "🔍 AWS Assume Role CLI - Environment Debug Information"
echo "====================================================="

echo ""
echo "📍 System Information:"
echo "  Operating System: $(uname -s 2>/dev/null || echo 'unknown')"
echo "  Architecture: $(uname -m 2>/dev/null || echo 'unknown')"
echo "  Kernel: $(uname -r 2>/dev/null || echo 'unknown')"

echo ""
echo "🐚 Shell Information:"
echo "  SHELL: ${SHELL:-'not set'}"
echo "  OSTYPE: ${OSTYPE:-'not set'}"
echo "  BASH_VERSION: ${BASH_VERSION:-'not set'}"

echo ""
echo "🪟 Windows Environment Variables:"
echo "  WINDIR: ${WINDIR:-'not set'}"
echo "  SYSTEMROOT: ${SYSTEMROOT:-'not set'}"
echo "  USERPROFILE: ${USERPROFILE:-'not set'}"
echo "  HOMEDRIVE: ${HOMEDRIVE:-'not set'}"
echo "  HOMEPATH: ${HOMEPATH:-'not set'}"

echo ""
echo "🛠️ Available Commands:"
echo "  winpty: $(command -v winpty 2>/dev/null || echo 'not found')"
echo "  cmd: $(command -v cmd 2>/dev/null || echo 'not found')"
echo "  powershell: $(command -v powershell 2>/dev/null || echo 'not found')"

echo ""
echo "📁 Current Directory:"
echo "  PWD: $(pwd)"
echo "  Directory contents:"
ls -la

echo ""
echo "🔍 AWS Assume Role Files:"
echo "  aws-assume-role.exe: $([ -f 'aws-assume-role.exe' ] && echo '✅ found' || echo '❌ not found')"
echo "  aws-assume-role-unix: $([ -f 'aws-assume-role-unix' ] && echo '✅ found' || echo '❌ not found')"
echo "  aws-assume-role-macos: $([ -f 'aws-assume-role-macos' ] && echo '✅ found' || echo '❌ not found')"
echo "  INSTALL.sh: $([ -f 'INSTALL.sh' ] && echo '✅ found' || echo '❌ not found')"
echo "  INSTALL.ps1: $([ -f 'INSTALL.ps1' ] && echo '✅ found' || echo '❌ not found')"

echo ""
echo "🧪 OS Detection Test:"
# Replicate the detection logic from INSTALL.sh
OS="unknown"
if [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macos"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="linux"
elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "cygwin" ]] || [[ "$OSTYPE" == "win32" ]]; then
    OS="gitbash"
elif [[ "$OSTYPE" == *"msys"* ]] || [[ "$OSTYPE" == *"mingw"* ]] || [[ "$OSTYPE" == *"cygwin"* ]]; then
    OS="gitbash"
elif command -v winpty >/dev/null 2>&1 || [[ -n "$WINDIR" ]] || [[ -n "$SYSTEMROOT" ]]; then
    echo "  Windows environment detected via fallback method"
    OS="gitbash"
fi

echo "  Detected OS: $OS"

case $OS in
    "macos")
        EXPECTED_BINARY="aws-assume-role-macos"
        ;;
    "linux")
        EXPECTED_BINARY="aws-assume-role-unix"
        ;;
    "gitbash")
        EXPECTED_BINARY="aws-assume-role.exe"
        ;;
    *)
        EXPECTED_BINARY="unknown"
        ;;
esac

echo "  Expected binary: $EXPECTED_BINARY"
echo "  Binary exists: $([ -f "$EXPECTED_BINARY" ] && echo '✅ yes' || echo '❌ no')"

echo ""
echo "💡 Recommendations:"
if [[ "$OS" == "unknown" ]]; then
    echo "  ❌ OS detection failed. Try:"
    echo "     1. OSTYPE=msys ./INSTALL.sh (for Git Bash)"
    echo "     2. Use PowerShell: .\INSTALL.ps1"
    echo "     3. Manual installation (see README.md)"
elif [[ "$OS" == "gitbash" ]] && [[ ! -f "aws-assume-role.exe" ]]; then
    echo "  ❌ Git Bash detected but aws-assume-role.exe not found"
    echo "     1. Ensure you downloaded the correct release package"
    echo "     2. Extract the full package contents"
    echo "     3. Run this script from the extracted directory"
elif [[ "$OS" == "gitbash" ]] && [[ -f "aws-assume-role.exe" ]]; then
    echo "  ✅ Git Bash detected and aws-assume-role.exe found"
    echo "     The installation should work. If it doesn't, please report this output."
else
    echo "  ✅ Environment looks good for installation"
fi

echo ""
echo "🎯 Next Steps:"
echo "  1. If using Git Bash, run: ./INSTALL.sh"
echo "  2. If using PowerShell, run: .\INSTALL.ps1"
echo "  3. If issues persist, share this debug output for support"

echo ""
echo "📋 Debug completed!" 